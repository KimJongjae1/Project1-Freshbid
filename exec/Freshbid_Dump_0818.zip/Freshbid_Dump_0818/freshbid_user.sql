-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: i13a305.p.ssafy.io    Database: freshbid
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` enum('ROLE_ADMIN','ROLE_CUSTOMER','ROLE_SELLER') NOT NULL DEFAULT 'ROLE_CUSTOMER',
  `nickname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `profile_image` varchar(100) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `introduction` text,
  `account_number` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','{bcrypt}$2a$10$WnPCxYFMTtsczkg0EDsfIeHYE5HgxqKGOiu5yRCHH9b6Jpu12oP4e','ROLE_ADMIN','admin','admin@gmail.com',NULL,'01000000000',NULL,'','','2025-08-11 10:11:15','2025-08-11 10:11:15',0),(2,'seller11','{bcrypt}$2a$10$rrCKP/I/boeaF2CC7eX1L.Ig0g.RLOKZnURkgMlXv9zML558i3ZaK','ROLE_SELLER','seller11','seller11@gmail.com',NULL,'01000000001',NULL,'','','2025-08-11 10:08:09','2025-08-11 10:08:09',0),(3,'seller22','{bcrypt}$2a$10$mahwVOIbhdtJnEjRuDfq4.TsK7ohXxDJmH99bYrOUjweiH4iytJ/O','ROLE_SELLER','seller22','seller22@gmail.com',NULL,'01000000002',NULL,'','','2025-08-11 10:08:33','2025-08-11 10:08:33',0),(4,'seller33','{bcrypt}$2a$10$rsIs1awxlTbSJazkmReLFOgNEzBVzlmmOU.4dbiCvHtnB490hpZ5O','ROLE_SELLER','seller33','seller33@gmail.com',NULL,'01000000003',NULL,'','','2025-08-11 10:08:43','2025-08-11 10:08:43',0),(5,'customer1','{bcrypt}$2a$10$RJ/T.zlM64Cq/VI0C1qII.KIxrCa1hAGLDL66m74dxPWHFzBKbN8O','ROLE_CUSTOMER','customer1','customer1@gmail.com',NULL,'01000000004',NULL,'','','2025-08-11 10:09:10','2025-08-11 10:09:10',0),(6,'customer2','{bcrypt}$2a$10$z1GAmYuVuleitlLXLEpQj.XfN2SYbJd8V4JyrJ7RRu.aVzSDBZUY6','ROLE_CUSTOMER','customer2','customer2@gmail.com',NULL,'01000000005',NULL,'','','2025-08-11 10:09:58','2025-08-11 10:09:58',0),(7,'customer3','{bcrypt}$2a$10$QZqK3zHIe23QG9Wj04EypehGrSqy.6BRBPQZFVVdl15Tr/SjVbLQ2','ROLE_CUSTOMER','customer3','customer3@gmail.com',NULL,'01000000006',NULL,'','','2025-08-11 10:10:10','2025-08-11 10:10:10',0),(8,'customer4','{bcrypt}$2a$10$6hdX.Pz8RM5G4PO8O.iu.OE.uWiILelEZl.Jrvg5/3F5n/Tht5pn6','ROLE_CUSTOMER','customer4','customer4@gmail.com',NULL,'01000000007',NULL,'','','2025-08-11 10:10:21','2025-08-11 10:10:21',0),(9,'customer5','{bcrypt}$2a$10$S0PlwfVZPZCMXVj2XSVVOO/35ttR3yl2xYaiAHEbEJ52JsD.q3bbi','ROLE_CUSTOMER','customer5','customer5@gmail.com',NULL,'01000000008',NULL,'','','2025-08-11 10:10:31','2025-08-11 10:10:31',0),(10,'customer6','{bcrypt}$2a$10$GoGbQte13fg3JWPLNwd1teilI.SJEMz7oEMpcgfcVdh27525J/Hxa','ROLE_CUSTOMER','customer6','customer6@gmail.com',NULL,'01000000009',NULL,'','','2025-08-11 10:10:51','2025-08-11 10:10:51',0),(11,'elooseller','{bcrypt}$2a$10$5O14Bz5.zpQXcEKpkx8kBOCfiPogW.o5LbulwSp5KuucQxNQS7phy','ROLE_SELLER','eloo_seller','iroo2001@naver.com',NULL,'01012341234',NULL,NULL,'','2025-08-15 10:21:34','2025-08-15 10:21:34',0),(12,' seungju','{bcrypt}$2a$10$EGQG.CJpnm7htyzd4LoWte1.e084iu4ViQh4QVUF6mbfQejP4JNH2','ROLE_CUSTOMER','윤승주','sdfsd@dfd.com',NULL,'01021892914',NULL,NULL,'','2025-08-15 10:29:13','2025-08-15 10:29:13',0),(13,'parkjs82','{bcrypt}$2a$10$gHcug1M8f.RrmLgDtdx49.tQV6xjn4POKUK1blA4vUcaKOx0tTD7a','ROLE_CUSTOMER','parkjs82','parkjs82@gmail.com',NULL,'01091767857',NULL,NULL,'','2025-08-15 10:37:04','2025-08-15 10:37:04',0),(14,'customertest1','{bcrypt}$2a$10$TZUipRv69q3ArjF0PadVJ.QxibI3VGtF7.tdqQZndHR6.VduB8r7i','ROLE_CUSTOMER','testuser','iroo2001@naver.com',NULL,'01012341234',NULL,NULL,'','2025-08-15 11:25:09','2025-08-15 11:25:09',0),(15,'eloocustomer','{bcrypt}$2a$10$41HCWRLWCeIpbUu8ufaXWu6U3MemC/tFf1zpTBu2DlldnrztKRIcW','ROLE_CUSTOMER','customer_test','t@test.t',NULL,'01012341234',NULL,NULL,'','2025-08-15 13:17:59','2025-08-15 13:17:59',0),(16,'test1234','{bcrypt}$2a$10$1OCGJp7AZwqVNe20WM2Y/OSUk1cZFsnZE815Fs961flT6v1G0Ls3.','ROLE_CUSTOMER','test1234','test1234@gmail.com',NULL,'01000000000',NULL,NULL,'','2025-08-15 13:31:24','2025-08-15 13:31:24',0),(17,'yejin-seller','{bcrypt}$2a$10$7saADvO0iBmoZwS4tpIZO..s4PnphekLmC8r8xmmGjtolSggVqUYu','ROLE_SELLER','조예진','yejinlala427@naver.com',NULL,'01047492656',NULL,NULL,'','2025-08-15 22:15:54','2025-08-15 22:15:54',0),(18,'qqq111','{bcrypt}$2a$10$Gkc/f2KSb3ce0jru52akNeA9csKtIpFpk4OyruDKAYFe0/wFdorwq','ROLE_CUSTOMER','qqqq','ew@ss.com',NULL,'01011111111',NULL,NULL,'','2025-08-18 08:42:24','2025-08-18 08:42:24',0),(19,'seller0818','{bcrypt}$2a$10$h/bgzkL4ZoU0SPGUZFYMkOYumaAmSpjcDpYNqmQShtmpkPZAxfTPu','ROLE_SELLER','바나나가참맛있어요','seller@gmail.com',NULL,'01012345678','최고의 수확만 팝니다.',NULL,'','2025-08-18 09:06:43','2025-08-18 09:58:02',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18 10:03:34
